
export function Card({ children, className, ...props }) {
  return <div className={`rounded-xl border p-4 shadow ${className}`} {...props}>{children}</div>;
}
export function CardContent({ children }) {
  return <div>{children}</div>;
}
