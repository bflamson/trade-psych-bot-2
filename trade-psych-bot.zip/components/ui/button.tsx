
export function Button({ children, onClick, className = '', variant = '', ...props }) {
  const base = "px-4 py-2 rounded-xl font-semibold";
  const style = variant === "ghost" ? "bg-transparent text-gray-700 hover:bg-gray-100" :
                variant === "outline" ? "border border-gray-300 bg-white hover:bg-gray-50" :
                "bg-blue-600 text-white hover:bg-blue-700";
  return <button className={`${base} ${style} ${className}`} onClick={onClick} {...props}>{children}</button>;
}
